TaM Bookkeeping Android project
GitHub Actions builds app-debug.apk and uploads it as an artifact.
No APK is included in this ZIP. Android build has not been verified in this environment.
